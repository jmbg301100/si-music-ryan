<?php

session_start();

define ('URL', 'http://localhost/a/');

define ('ASSET', URL . 'layout/assets/');

require_once "vendor/autoload.php";
?>