<h2> Login Sistem</h2>

<form action="login_proses.php" method="POST">
    <table>
    <tr>
        <td>Username</td>
        <td><input type="text" name="i_username"></td>
    </tr>
    <tr>
        <td>Password</td>
        <td><input type="text" name="i_password"></td>
    </tr>
    <tr>
        <td></td>
        <td><input type="submit" value="LOGIN" name="b_login"></td>
            
    </table>
</form>